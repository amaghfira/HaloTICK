<style>
    .contain {
        margin: auto;
        margin-top: 50px;
    }
</style>

<div class="contain">
    <p>
        ipds6400@bps.go.id
    </p>
    <p>
        BPS Provinsi Kalimantan Timur 
    </p>
</div>

